<footer class="pt-4 my-md-5 pt-md-5 border-top">
    <div class="row">
      <div class="text-center">
        <img class="mb-2" src="https://getbootstrap.com/docs/5.1/assets/brand/bootstrap-logo.svg" alt="" width="24" height="19">
        <small class="d-block mb-3 text-muted">&copy; 2021</small>
      </div>
        
      
    </div>
  </footer>