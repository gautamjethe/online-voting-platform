
    const plyr = new Plyr('#player', {
        autoplay: true,
        controls: [''],
        fullscreen: {
        	enabeled: false
        },
        loop: { 
        	active: true }
    });


