<?php
$filter = json_decode(
    file_get_contents("src/Uploady/Handler/filter.json"),
    true
);

$page = 'supported';
