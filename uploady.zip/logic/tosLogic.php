<?php
$page = 'tos';
