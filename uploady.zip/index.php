<?php
include_once 'session.php';
include_once APP_PATH . 'logic/indexLogic.php';
?>
<!DOCTYPE html>
<html lang="en">
<html>

<head>
  <meta charset="UTF-8" />
  <?php include_once 'components/header.php'; ?>
  <title>
    <?= $st['website_name'] ?> - File Uploading Service
  </title>
  <?php include_once 'components/css.php'; ?>
</head>

<body>


  <?php include_once 'components/navbar.php'; ?>

  <div id="wrapper">
    <div id="content-wrapper">
      <div class="container pb-5 pt-5">
        <div class="row justify-content-center text-center">
          <div class="col-sm-12 col-md-8 col-lg-8">
            <div class="card">
              <div class="card-header">
                <b>Upload Your Files</b>
              </div>
              <div class="card-body">
                <div id="upload_alert"></div>
                <div id="upload_alert">
                  <?php if (isset($_GET['error'])) : ?>
                    <?= $utils->alert(
                      'You are trying to bypass the security measures',
                      'danger'
                    ); ?>
                  <?php endif; ?>
                </div>
                <p class="card-title lead font-weight-bold text-dark">
                  Select Files
                </p>
                <form id="uploadForm" enctype="multipart/form-data" role="form" method="POST" action="upload.php">
                <div class="mb-3">
                  <div class="form-group" id="dvFile">
                    <input class="form-control" type="file" class="form-control-file pt-2" name="file[]" />
                    </div>
                    
                  </div>
                  <br>
                  <div class="alert alert-success" role="alert">
                    <h4 class="alert-heading">Well done!</h4>
                    <p>Aww yeah, you successfully read this important alert message. This example text is going to run a bit longer so that you can see how spacing within an alert works with this kind of content.</p>
                
  
                  </div>
                  <!-- Progress bar -->
<div class="progress">
    <div class="progress-bar"></div>
</div>
<div id="uploadStatus"></div>

                  <div class="custom-control custom-checkbox m-3">
                    <input type="checkbox" class="custom-control-input" id="tos">
                    <label class="custom-control-label" for="tos">
                      I agree to the <a href="terms.php">Terms and Conditions</a>
                    </label>
                  </div>

                  <button id="submit" name="submit" type="submit" class="btn btn-primary" disabled>
                    <span class="fa fa-upload"></span> Upload Files
                  </button>
                  <button type="button" id="add_more" class="btn btn-primary text-white">
                    <span class="fa fa-plus"></span> Add a File
                  </button>
                </form>
              </div>
              <div class="card-footer mb-0">
                <p class="mb-0">
                  Note: Supported formats:
                  <a href="supported.php">See Here...</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script>
$(document).ready(function(){
    // File upload via Ajax
    $("#uploadForm").on('submit', function(e){
        e.preventDefault();
        $.ajax({
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = ((evt.loaded / evt.total) * 100);
                        $(".progress-bar").width(percentComplete + '%');
                        $(".progress-bar").html(percentComplete+'%');
                    }
                }, false);
                return xhr;
            },
            type: 'POST',
            url: 'upload.php',
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            beforeSend: function(){
                $(".progress-bar").width('0%');
                $('#uploadStatus').html('<img src="images/loading.gif"/>');
            },
            error:function(){
                $('#uploadStatus').html('<p style="color:#EA4335;">File upload failed, please try again.</p>');
            },
            success: function(resp){
                if(resp == 'ok'){
                    $('#uploadForm')[0].reset();
                    $('#uploadStatus').html('<p style="color:#28A74B;">File has uploaded successfully!</p>');
                }else if(resp == 'err'){
                    $('#uploadStatus').html('<p style="color:#EA4335;">Please select a valid file to upload.</p>');
                }
            }
        });
    });
	
    // File type validation
    $("#fileInput").change(function(){
        var allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.ms-office', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
        var file = this.files[0];
        var fileType = file.type;
        if(!allowedTypes.includes(fileType)){
            alert('Please select a valid file (PDF/DOC/DOCX/JPEG/JPG/PNG/GIF).');
            $("#fileInput").val('');
            return false;
        }
    });
});
</script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <?php include_once 'components/footer.php'; ?>

  <?php include_once 'components/js.php'; ?>
</body>

</html>

</html>