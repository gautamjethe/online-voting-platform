<?php
$utils->style(
    'https://stackpath.bootstrapcdn.com/bootswatch/4.3.1/' .
        strtolower($st['theme_name']) .
        '/bootstrap.min.css'
);

$utils->style(
    'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.css'
);

$utils->style('css/custom.css');

$utils->style(
    'https://cdn.boomcdn.com/libs/owl-carousel/2.3.4/assets/owl.carousel.min.css'
);

$utils->style(
    'https://cdn.boomcdn.com/libs/owl-carousel/2.3.4/assets/owl.theme.default.min.css'
);
$utils->style(
    'https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css'
);
$utils->style(
    'https://cdn.plyr.io/3.6.8/plyr.css'
);
