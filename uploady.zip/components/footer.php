<footer class="py-5 my-sm-10 bg-primary">
  <div class="container-fluid my-auto">
    <p class="m-0 text-center text-white">
      Copyright &copy;
      <?= $st['website_name'] . " - " . date('Y') ?>
    </p>
  </div>
</footer>