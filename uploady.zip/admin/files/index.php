<?php
include_once '../session.php';

$utils->redirect($utils->siteUrl('/admin/files/view.php'));
