<?php
$utils->style('css/styles.css', 'admin/assets');
$utils->script(
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js'
);
