<?php
$utils->script('https://code.jquery.com/jquery-3.5.1.slim.min.js');
$utils->script(
    'https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js'
);
$utils->script('js/scripts.js', 'admin/assets');
