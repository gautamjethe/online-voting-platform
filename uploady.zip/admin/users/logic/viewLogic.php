<?php

$users = $user->getUsers();
