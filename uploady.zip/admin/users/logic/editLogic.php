<?php

$user_data = $user->getUserData($_GET['username']);
