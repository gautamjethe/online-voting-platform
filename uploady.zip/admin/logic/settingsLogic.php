<?php
$smtp_types = ["None", "SSL", "TLS"];

$bootswatch_themes = [
    'cerulean' => 'Cerulean',
    'cosmo' => 'Cosmo',
    'cyborg' => 'Cyborg',
    'darkly' => 'Darkly',
    'flatly' => 'Flatly',
    'journal' => 'Journal',
    'litera' => 'Litera',
    'lumen' => 'Lumen',
    'lux' => 'Lux',
    'materia' => 'Materia',
    'minty' => 'Minty',
    'pulse' => 'Pulse',
    'sandstone' => 'Sandstone',
    'simplex' => 'Simplex',
    'sketchy' => 'Sketchy',
    'slate' => 'Slate',
    'solar' => 'Solar',
    'spacelab' => 'Spacelab',
    'superhero' => 'Superhero',
    'united' => 'United',
    'yeti' => 'Yeti',
];
